﻿/// <author>Slater de Mont</author>
/// <date>11/28/2018</date>
/// <summary>
/// Menu script that allows player to select game icon and game size
/// </summary>

using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Menu : MonoBehaviour {
	public GameObject threebyGame;
	public GameObject fourbyGame;
	public GameObject textBox;
	public GameObject pieceSelect;
	public GameObject gameSelect;


	private Sprite player1Image;
	private Sprite player2Image;
	private int playerSelecting = 1;
	private bool isDoneSelecting = false;

	//sets the player piece to the selected on and deselects the piece
	public void SetPiece(GameObject pieceClicked){
		if (isDoneSelecting == false) {
			pieceClicked.GetComponent<Button>().interactable = false;
			if (playerSelecting == 1) {
				player1Image = pieceClicked.GetComponent<Image> ().sprite;
				playerSelecting = 2;
				textBox.GetComponent<Text>().text = "Player 2 Select Piece";
			} else if (playerSelecting == 2) {
				player2Image = pieceClicked.GetComponent<Image> ().sprite;
				isDoneSelecting = true;
				pieceSelect.SetActive(false);
				gameSelect.SetActive(true);
			}
		}
	}

	//Select between 3x3 or 4x4 game
	public void SelectGameSize(int size){
		if (size == 3) {
			threebyGame.GetComponent<GameEngine>().player1 = player1Image;
			threebyGame.GetComponent<GameEngine>().player2 = player2Image;
			threebyGame.SetActive(true);
			this.gameObject.SetActive(false);
		}
		else if(size == 4) {
			fourbyGame.GetComponent<GameEngine>().player1 = player1Image;
			fourbyGame.GetComponent<GameEngine>().player2 = player2Image;
			fourbyGame.SetActive(true);
			this.gameObject.SetActive(false);
		}
	}
}
