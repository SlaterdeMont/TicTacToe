﻿/// <author>Slater de Mont</author>
/// <date>11/28/2018</date>
/// <summary>
/// Tile script that stores local variables and sets and reset the tiles
/// </summary>

using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Tile : MonoBehaviour {
	public GameEngine gameReference;
	public string location;
	public int playerNum;
	public string id = "";

	private bool isOccupied = false;
	public int moveNum;

	public void Start(){
		//sets the ID
		id = ".-E-" + location;
	}

	//sets the piece as the player's image and set the spot ID as the player
	public void SetPiece(int player, Sprite playerImage, int numMove){
		this.GetComponent<Image>().sprite = playerImage;
		playerNum = player;
		char playerID = ' '; 

		if(playerNum == 1){
			playerID = 'a';
		}else{
			playerID = 'b';
		}

		//id is the move number, the player who did the move, and then the tile location
		id = numMove + "-" + playerID + "-" + location;
	}

	//triggered by button onclick event, checks if spot is occupied and sends move to GameEngine
	public void WasClicked(){
		if (!isOccupied) {
			gameReference.TileClicked (this);
			isOccupied = true;
		}
	}

	//resets the tile
	public void Reset(Sprite resetImage){
		this.GetComponent<Image>().sprite = resetImage;
		isOccupied = false;
		playerNum = 0;
		id = ".-E-" + location;
	}
}
