﻿/// <author>Slater de Mont</author>
/// <date>11/28/2018</date>
/// <summary>
/// Controls game states and rules, set player tile images
/// </summary>

using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System.IO;
using System;
using System.Collections;
using System.Collections.Generic;

public class GameEngine : MonoBehaviour {

	public Sprite player1;
	public Sprite player2;
	public Sprite tileImage;
	public int gameSize;
	public GameObject winText;
	public GameObject winScreen;
	public Text playerTurnText;
	public int numMove = 1;

	private int playerNum;
	private Tile selectedTile;
	private Sprite currentplayerImage;

	//array of tiles and 2d array representing board
	public Tile[] tileArray;
	private Tile[,] tiles;

	//initializes game
	void Start () {
		tiles = new Tile[gameSize,gameSize];
		currentplayerImage = player1;
		playerNum = 1;
		PopulateArray ();
	}

	//Sets the selected tile and sets the tile
	public void TileClicked(Tile clickedTile){
		selectedTile = clickedTile;
		SetTile ();
	}

	//sets the tile, changes the text to display the current players turn, checks win conditions
	private void SetTile(){
		selectedTile.SetPiece (playerNum, currentplayerImage, numMove);
		numMove++;

		StoreMove ();

		if (playerNum == 1) {
			currentplayerImage = player2;
			playerNum = 2;
			playerTurnText.text = "Player 2 Turn";

		} else {
			currentplayerImage = player1;
			playerNum = 1;
			playerTurnText.text = "Player 1 Turn";
		}
		CheckWin ();
	}

	//create 2D array of tiles representing the game board
	private void PopulateArray(){
		int arrayIndex = 0;
		for (int i = 0; i < gameSize; i++)
		{	
			for (int j = 0; j < gameSize; j++)
			{
				tiles[i,j] = tileArray[arrayIndex];
				arrayIndex++;
			}
		}
		ResetGame ();
	}

	//checks rows, columns, and diagonals for matching pieces
	private void CheckWin(){
		//checkRows
		int num1 = 0;
		int num2 = 0;
		for (int i = 0; i < gameSize; i++) {
			for (int j = 0; j < gameSize; j++) {
				if(tiles [i, j].playerNum == 1){
					num1++;
				}else if(tiles [i, j].playerNum == 2){
					num2++;
				}

				if(num1 == gameSize){
					GameOver(1);
				}
				else if(num2 == gameSize){
					GameOver(2);
				}
			}
			num1 = 0;
			num2 = 0;
		}

		//check collumns
		num1 = 0;
		num2 = 0;
		for (int j = 0; j < gameSize; j++) {
			for (int i = 0; i < gameSize; i++) {
				if(tiles [i, j].playerNum == 1){
					num1++;
				}else if(tiles [i, j].playerNum == 2){
					num2++;
				}
				
				if(num1 == gameSize){
					GameOver(1);
				}
				else if(num2 == gameSize){
					GameOver(2);
				}
			}
			num1 = 0;
			num2 = 0;
		}

		//check diagonals
		num1 = 0;
		num2 = 0;
		for (int i = 0; i < gameSize; i++) {
			if(tiles [i, i].playerNum == 1){
				num1++;
			}else if(tiles [i, i].playerNum == 2){
				num2++;
			}

			if(num1 == gameSize){
				GameOver(1);
			}
			else if(num2 == gameSize){
				GameOver(2);
			}
		}

		num1 = 0;
		num2 = 0;

		int numIndex = 0;
		for (int i = gameSize - 1; i > -1; i--) {
			if(tiles [i, numIndex].playerNum == 1){
				num1++;
			}else if(tiles [i, numIndex].playerNum == 2){
				num2++;
			}
			
			if(num1 == gameSize){
				GameOver(1);
			}
			else if(num2 == gameSize){
				GameOver(2);
			}
			numIndex++;
		}
	}

	//turns on gameover screen 
	private void GameOver(int playerWon){
		winText.GetComponent<Text> ().text = "Player " + playerWon;
		winScreen.SetActive (true);
	}

	//Resets the game
	public void ResetGame(){
		for (int i = 0; i < gameSize; i++) {
			for (int j = 0; j < gameSize; j++) {
				tiles [i, j].Reset(tileImage);
			}
		}
		currentplayerImage = player1;
		playerNum = 1;
		playerTurnText.text = "Player 1 Turn";
		numMove = 1;
	}


	//Write the game board to a text file
	public void StoreMove(){
		string turnMove = "";

		for (int i = 0; i < gameSize; i++)
		{
			for (int j = 0; j < gameSize; j++)
			{
				turnMove += tiles[i,j].id + " ";
			}
			turnMove += "\n";
		}
		turnMove += "\n";
		
		File.AppendAllText("./Assets/Games/Games.txt", turnMove);
	}

}
